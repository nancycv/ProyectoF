<?php include 'header.php';?>

    <!-- Page Content -->
    <div class="container">
      <div class="row">
        <div class="col-lg-12 text-center">
          <h1 class="mt-5" style="color:red;">Sorry!</h1>
          <h3 style="color:red;">There is not enough stock to fulfill your buy.</h3>
          <br>
          <a href="./kart.php"><button class="btn btn-primary" >Return to Cart</button></a>
        </div>
      </div>
    </div>
