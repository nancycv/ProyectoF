<!DOCTYPE HTML>
<html>
  <head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Art Gallery</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Free HTML5 Website Template by gettemplates.co" />
	<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
	<meta name="author" content="gettemplates.co" />


	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

    <body>
<footer id="fh5co-footer" role="contentinfo">
	<div class="container">
		<div class="row row-pb-md">
			<div class="col-md-4 fh5co-widget">
				<h3>Art Gallery</h3>
				<p>Mexicanos apasionados por retratar cada detalle de ti en blanco y negro</p>
			</div>
			
		<div class="row copyright">
			<div class="row-md-12 text-center">
				<p>
					<small class="block">&copy; 2021 ArtGallery All Rights Reserved.</small> 
					<small class="block">Designed by nancy colin  Images: <a href="http://blog.gessato.com/" target="_blank">Gessato</a> &amp; <a href="http://unsplash.co/" target="_blank">Unsplash</a></small>
				</p>
				<p>
					<ul class="fh5co-social-icons">
						<li><a href="https://twitter.com/nancycv11"><i class="icon-twitter"></i></a></li>
						<li><a href="https://www.facebook.com/nancycolinv/"><i class="icon-facebook"></i></a></li>
						<li><a href="https://mail.google.com/mail/u/0/#inbox"><i class="icon-mail"></i></a></li>
						<li><a href="https://www.instagram.com/nancycv29/"><i class="icon-instagram"></i></a></li>
					</ul>
				</p>
			</div>
		</div>

		</div>
	</footer>

    
    </body>
    </html>